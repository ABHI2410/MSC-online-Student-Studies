<?php

namespace App\Http\Controllers\Api\V1;
use App\Http\Controllers\Controller;

use App\Models\programrequirements;
use App\Http\Requests\StoreprogramrequirementsRequest;
use App\Http\Requests\UpdateprogramrequirementsRequest;

class ProgramrequirementsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreprogramrequirementsRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(programrequirements $programrequirements)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(programrequirements $programrequirements)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateprogramrequirementsRequest $request, programrequirements $programrequirements)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(programrequirements $programrequirements)
    {
        //
    }
}
